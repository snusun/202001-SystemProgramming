#include <linux/debugfs.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>

#define LENGTH_MAX 1000

MODULE_LICENSE("GPL");

static struct dentry *dir, *inputdir, *ptreedir;
static struct task_struct *curr;

char out_str[LENGTH_MAX];
ssize_t length_temp, length_total = 0;

static ssize_t write_pid_to_input(struct file *fp, 
                                const char __user *user_buffer, 
                                size_t length, 
                                loff_t *position)
{
    	pid_t input_pid;
    	char temp_str[LENGTH_MAX];

	//initialize to 0
    	memset(out_str, 0, LENGTH_MAX);

	sscanf(user_buffer, "%u", &input_pid);
    	if(copy_from_user(temp_str, user_buffer, length))
        	return -EFAULT;

    	//find task_struct using input_pid
    	curr = pid_task(find_get_pid(input_pid), PIDTYPE_PID);
	//check
    	if(!curr) return -EINVAL;
    
	//Tracing process tree from input_pid to init(1) process
    	while(curr->pid != 0) 
	{
		// Make output format string: process_command (process_id)
        	length_temp = snprintf(temp_str, LENGTH_MAX, "%s (%d)\n", curr->comm, curr->pid);
        	//append the last result 
       	 	snprintf(temp_str+length_temp, LENGTH_MAX-length_temp, out_str);
		length_total += length_temp;
		strcpy(out_str, temp_str);
		curr = curr -> parent;
    	}
    	return length;
}

static ssize_t read_output(struct file *fp, 
                                char __user *user_buffer, 
                                size_t length, 
                                loff_t *position)
{
	//copy to user buffer
    	return simple_read_from_buffer(user_buffer, length, position, out_str, length_total);
}

static const struct file_operations dbfs_fops_write = {
    .write = write_pid_to_input,
};

static const struct file_operations dbfs_fops_read = {
    .read = read_output,
};

static int __init dbfs_module_init(void)
{
	// Implement init module code
    	dir = debugfs_create_dir("ptree", NULL);
    
	if (!dir) 
	{
        	pr_err("Cannot create ptree dir\n");
        	return -1;
    	}
    
	inputdir = debugfs_create_file("input", 00700, dir, NULL, &dbfs_fops_write);
    	if (!inputdir) 
	{
        	pr_err("Cannot create inputdir file\n");
        	return -1;
    	}
    
	ptreedir = debugfs_create_file("ptree", 00700, dir, NULL, &dbfs_fops_read); // Find suitable debugfs API
    	if (!ptreedir) 
	{
        	pr_err("Cannot create ptreedir file\n");
        	return -1;
    	}
    	printk("dbfs_ptree module initialize done\n");
    
	return 0;
}

static void __exit dbfs_module_exit(void)
{
	// Implement eixt module code

	//remove recursively a directory tree in debugfs that was previously
	//created with a call to another debugfs function
    	debugfs_remove_recursive(dir);    
	printk("dbfs_ptree module exit\n");
}

module_init(dbfs_module_init);
module_exit(dbfs_module_exit);
